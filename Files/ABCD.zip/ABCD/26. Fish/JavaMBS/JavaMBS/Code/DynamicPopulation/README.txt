To compile and run with the modified Fish class, you can do one
of the following.

    -   In the Code directory, rename the Fish.java file. (For
        example, you could rename it origFish.java).  Then move
        the Fish.java file from this directory to the Code directory.
        Compile and run as usual.

    -   Alternatively, you could copy everything from the Code
        directory EXCEPT the Fish.java file to this directory,
        then compile and run as usual.

    -   If you have modified the Fish.java file and would like
        to keep your changes, follow the directions in the
        FishModsForChap3.txt file in the Code directory.  It
        provides instructions and code for making the appropriate
        modifications to your own version of Fish.java.
