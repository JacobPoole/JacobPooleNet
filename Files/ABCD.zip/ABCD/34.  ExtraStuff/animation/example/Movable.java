import objectdraw.*;
import java.awt.*;

public interface Movable
{
	public void move(double dx, double dy);
}