public abstract class Food
{
	public abstract int howMany();
}
