public abstract class Fruit
{
	public abstract double getWeight();
}
