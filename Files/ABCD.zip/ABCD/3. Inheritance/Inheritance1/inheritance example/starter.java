class starter {
        public static void main(String args[])
        {
//  	This is how you make a comment in java (c++ too)
//	neat is a reference to a String object.
//	This line constructs a String object and sets its value to Happy.
		String neat = new String("Happy");
		System.out.print(neat); 
		System.out.print(neat);
		System.out.println(neat);
		System.out.print(neat + "sad");
        }
        
}
