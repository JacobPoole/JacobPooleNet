import objectdraw.*;
import java.awt.*;

public abstract class Movable
{
	public abstract void move(double dx, double dy);
}